import React, { useState } from 'react';
import { View, Text, Pressable, ScrollView, StyleSheet, TextInput, useWindowDimensions, StatusBar } from 'react-native';
import * as DocumentPicker from 'expo-document-picker';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Feather, MaterialCommunityIcons } from '@expo/vector-icons';

const C = {
  navy: '#192D47', blue: '#0878F9', pale: '#E5F0FF', bg: '#F7FAFE',
  text: '#172B49', muted: '#60779A', border: '#E0EAF6', white: '#FFFFFF',
  red: '#FF5559', green: '#20B477',
};

type FileRow = {
  id: string; name: string; kind: string; size: string;
  color: string; icon: React.ComponentProps<typeof MaterialCommunityIcons>['name'];
  tab: string;
};

const FILES: FileRow[] = [
  { id: '1', name: 'Project_Proposal.pdf', kind: 'PDF document', size: '2.4 MB', color: '#F0444A', icon: 'file-pdf-box', tab: 'Recent files' },
  { id: '2', name: 'Screenshot_20251030.png', kind: 'Image', size: '1.8 MB', color: '#147CF5', icon: 'file-image', tab: 'Recent files' },
  { id: '3', name: 'Resume.docx', kind: 'Word document', size: '856 KB', color: '#1877F2', icon: 'file-document', tab: 'Recent files' },
  { id: '4', name: 'Budget_Sheet.xlsx', kind: 'Excel spreadsheet', size: '1.2 MB', color: '#19B875', icon: 'file-excel', tab: 'Recent files' },
  { id: '5', name: 'Source_Code.zip', kind: 'ZIP archive', size: '4.6 MB', color: '#71839E', icon: 'file-archive', tab: 'Recent files' },
  { id: '6', name: 'Meeting_Notes.docx', kind: 'Word document', size: '420 KB', color: '#1877F2', icon: 'file-document', tab: 'Documents' },
  { id: '7', name: 'Project_Plan.pdf', kind: 'PDF document', size: '1.6 MB', color: '#F0444A', icon: 'file-pdf-box', tab: 'Documents' },
  { id: '8', name: 'Screenshot.png', kind: 'Image', size: '1.8 MB', color: '#147CF5', icon: 'file-image', tab: 'Images' },
  { id: '9', name: 'Photo.jpg', kind: 'Image', size: '3.1 MB', color: '#147CF5', icon: 'file-image', tab: 'Images' },
  { id: '10', name: 'Download.zip', kind: 'ZIP archive', size: '4.6 MB', color: '#71839E', icon: 'file-archive', tab: 'Downloads' },
];

const TABS = [
  { label: 'Recent files', icon: 'clock' as const },
  { label: 'Documents', icon: 'file-text' as const },
  { label: 'Images', icon: 'image' as const },
  { label: 'Downloads', icon: 'download' as const },
];

function Sidebar({ onNavigate }: { onNavigate: (page: string) => void }) {
  const items = [
    { label: 'Home', icon: 'home' as const },
    { label: 'History', icon: 'clock' as const },
    { label: 'Quarantine', icon: 'archive' as const },
    { label: 'Settings', icon: 'settings' as const },
  ];
  return (
    <View style={s.sidebar}>
      <View style={s.brand}>
        <MaterialCommunityIcons name="shield-check" size={39} color={C.blue} />
        <Text style={s.brandText}>Security <Text style={{ color: '#8EC5FF' }}>Scanner</Text></Text>
      </View>
      <View style={s.navList}>
        {items.map(item => (
          <Pressable key={item.label} onPress={() => onNavigate(item.label)} style={s.navItem}>
            <Feather name={item.icon} size={21} color="#D4E0F0" />
            <Text style={s.navText}>{item.label}</Text>
            {item.label === 'Quarantine' && <View style={s.badge}><Text style={s.badgeText}>2</Text></View>}
          </Pressable>
        ))}
      </View>
      <View style={s.privacy}>
        <MaterialCommunityIcons name="shield-check-outline" size={26} color="#75B8FF" />
        <View style={{ flex: 1 }}>
          <Text style={s.privacyTitle}>Files stay on your phone by default.</Text>
          <Text style={s.privacyCopy}>We don't upload your files without your permission.</Text>
        </View>
      </View>
    </View>
  );
}

export default function SecurityScannerFileSelectionScreen() {
  const { width } = useWindowDimensions();
  const desktop = width >= 1000;
  const [tab, setTab] = useState('Recent files');
  const [selected, setSelected] = useState<string | null>(null);
  const [deviceFile, setDeviceFile] = useState<DocumentPicker.DocumentPickerAsset | null>(null);
  const [message, setMessage] = useState('');
  const visible = FILES.filter(file => file.tab === tab);
  const chosen = deviceFile?.name ?? visible.find(file => file.id === selected)?.name;

  const browse = async () => {
    try {
      const result = await DocumentPicker.getDocumentAsync({ type: '*/*', copyToCacheDirectory: true });
      if (!result.canceled) {
        setDeviceFile(result.assets[0]);
        setSelected(null);
        setMessage(`Selected ${result.assets[0].name}. Tap “Scan selected file” to continue.`);
      }
    } catch {
      setMessage('Could not open the device file picker. Please try again.');
    }
  };

  const navigate = (page: string) => {
    setMessage(page === 'Home' ? '' : `${page} screen is not included in this component yet.`);
  };

  return (
    <SafeAreaView style={s.safe}>
      <StatusBar barStyle="light-content" backgroundColor={C.navy} />
      <View style={s.app}>
        {desktop && <Sidebar onNavigate={navigate} />}
        <View style={s.content}>
          <View style={s.topbar}>
            {!desktop && <Text style={s.mobileBrand}>🛡 Security <Text style={{ color: '#8EC5FF' }}>Scanner</Text></Text>}
            <Feather name="user" size={20} color={C.navy} />
            <Text style={s.user}>User</Text>
            <Feather name="chevron-down" size={16} color="#8CA0BC" />
          </View>
          <ScrollView contentContainerStyle={[s.page, !desktop && s.pageMobile]}>
            <Pressable onPress={() => navigate('Home')} style={s.back}>
              <Feather name="arrow-left" size={20} color={C.blue} />
              <Text style={s.backText}>Back to Home</Text>
            </Pressable>

            <View style={s.intro}>
              <View style={s.heroIcon}>
                <MaterialCommunityIcons name="file-document-check-outline" size={72} color={C.blue} />
              </View>
              <Text style={s.heading}>Choose a file to scan</Text>
              <Text style={s.subtitle}>Select a file from your device. You choose which file to share{"\n"}with the scanner. Files stay on your phone by default.</Text>
            </View>

            {!!message && <View style={s.message}><Feather name="info" size={17} color={C.muted} /><Text style={s.messageText}>{message}</Text><Pressable onPress={() => setMessage('')}><Feather name="x" size={16} color={C.muted} /></Pressable></View>}

            <View style={s.panel}>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={s.tabs}>
                {TABS.map(item => (
                  <Pressable key={item.label} onPress={() => { setTab(item.label); setSelected(null); setDeviceFile(null); setMessage(''); }} style={[s.tab, tab === item.label && s.tabActive]}>
                    <Feather name={item.icon} size={19} color={tab === item.label ? C.blue : '#8296B5'} />
                    <Text style={[s.tabText, tab === item.label && s.tabTextActive]}>{item.label}</Text>
                  </Pressable>
                ))}
              </ScrollView>

              <View style={s.fileList}>
                {visible.map(file => {
                  const active = selected === file.id;
                  return (
                    <Pressable key={file.id} onPress={() => { setSelected(file.id); setDeviceFile(null); setMessage(''); }} style={[s.fileRow, active && s.fileRowSelected]}>
                      <View style={[s.fileIcon, { backgroundColor: file.color }]}><MaterialCommunityIcons name={file.icon} size={25} color={C.white} /></View>
                      <Text numberOfLines={1} style={s.fileName}>{file.name}</Text>
                      <Text numberOfLines={1} style={s.fileKind}>{file.kind}</Text>
                      <Text style={s.fileSize}>{file.size}</Text>
                      <View style={[s.radio, active && s.radioActive]}>{active && <View style={s.radioDot} />}</View>
                    </Pressable>
                  );
                })}
              </View>

              {!!chosen && <View style={s.chosen}><Feather name="check-circle" size={16} color={C.green} /><Text numberOfLines={1} style={s.chosenText}>Selected: {chosen}</Text></View>}

              <View style={s.actions}>
                <Pressable style={s.scanButton} onPress={() => setMessage(chosen ? `Ready to scan ${chosen}. Connect your scanning engine to perform an actual threat scan.` : 'Select a file from the list or browse your device first.')}>
                  <Text style={s.scanText}>Scan selected file</Text><Feather name="arrow-right" size={19} color={C.white} />
                </Pressable>
                <Pressable style={s.browseButton} onPress={browse}><Feather name="folder" size={17} color={C.blue} /><Text style={s.browseText}>Browse device</Text></Pressable>
                <Pressable style={s.cancelButton} onPress={() => navigate('Home')}><Text style={s.cancelText}>Cancel</Text></Pressable>
              </View>
            </View>

            <View style={s.info}>
              <Feather name="info" size={17} color="#6688B8" />
              <Text style={s.infoText}>If you can’t find your file, make sure you have the right permission to access it. If the file can’t be read, you’ll see an error message.</Text>
            </View>
          </ScrollView>
        </View>
      </View>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  safe: { flex: 1, backgroundColor: C.bg },
  app: { flex: 1, flexDirection: 'row', backgroundColor: C.bg },
  sidebar: { width: 280, backgroundColor: C.navy, paddingHorizontal: 16, paddingTop: 15, paddingBottom: 22 },
  brand: { flexDirection: 'row', alignItems: 'center', gap: 9, paddingHorizontal: 8, paddingBottom: 22, borderBottomWidth: 1, borderBottomColor: '#263D58' },
  brandText: { color: C.white, fontSize: 21, fontWeight: '800' },
  navList: { marginTop: 10, gap: 7 },
  navItem: { minHeight: 45, borderRadius: 10, paddingHorizontal: 14, flexDirection: 'row', alignItems: 'center', gap: 14 },
  navText: { color: '#F0F5FC', fontSize: 15, flex: 1 },
  badge: { minWidth: 23, height: 23, borderRadius: 12, backgroundColor: C.red, alignItems: 'center', justifyContent: 'center' },
  badgeText: { color: C.white, fontSize: 12, fontWeight: '700' },
  privacy: { marginTop: 'auto', borderTopWidth: 1, borderTopColor: '#314660', paddingTop: 18, flexDirection: 'row', gap: 12 },
  privacyTitle: { color: C.white, fontSize: 12, lineHeight: 18, fontWeight: '700' },
  privacyCopy: { color: '#CBD7E8', fontSize: 11, lineHeight: 17, marginTop: 5 },
  content: { flex: 1, minWidth: 0 },
  topbar: { height: 62, backgroundColor: C.white, borderBottomWidth: 1, borderBottomColor: '#E8EEF6', paddingHorizontal: 28, flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-end', gap: 10 },
  mobileBrand: { color: C.text, fontSize: 14, fontWeight: '800', marginRight: 'auto' },
  user: { color: C.text, fontSize: 14 },
  page: { paddingHorizontal: 44, paddingTop: 26, paddingBottom: 40, flexGrow: 1 },
  pageMobile: { paddingHorizontal: 16, paddingTop: 20 },
  back: { alignSelf: 'flex-start', flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 4 },
  backText: { color: C.blue, fontSize: 13 },
  intro: { alignItems: 'center', marginBottom: 26 },
  heroIcon: { width: 102, height: 102, borderRadius: 30, backgroundColor: '#E6F1FF', alignItems: 'center', justifyContent: 'center', marginBottom: 16 },
  heading: { color: C.text, fontSize: 33, lineHeight: 40, fontWeight: '800', textAlign: 'center' },
  subtitle: { color: C.muted, fontSize: 15, lineHeight: 25, textAlign: 'center', marginTop: 7 },
  message: { flexDirection: 'row', alignItems: 'center', gap: 9, padding: 12, backgroundColor: '#EFF6FF', borderColor: '#D9E9FF', borderWidth: 1, borderRadius: 9, marginBottom: 12 },
  messageText: { flex: 1, color: C.text, fontSize: 12, lineHeight: 18 },
  panel: { backgroundColor: C.white, borderWidth: 1, borderColor: C.border, borderRadius: 11, paddingBottom: 14, overflow: 'hidden' },
  tabs: { flexDirection: 'row', minWidth: '100%', borderBottomWidth: 1, borderBottomColor: '#E8EEF6', paddingHorizontal: 12 },
  tab: { minWidth: 150, minHeight: 66, paddingHorizontal: 14, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10, borderBottomWidth: 2, borderBottomColor: 'transparent' },
  tabActive: { borderBottomColor: C.blue },
  tabText: { color: '#7A8EAE', fontSize: 14 },
  tabTextActive: { color: C.blue },
  fileList: { paddingHorizontal: 22 },
  fileRow: { minHeight: 62, flexDirection: 'row', alignItems: 'center', gap: 16, borderBottomWidth: 1, borderBottomColor: '#E8EEF6', paddingHorizontal: 12 },
  fileRowSelected: { backgroundColor: '#F1F7FF' },
  fileIcon: { width: 29, height: 32, borderRadius: 6, alignItems: 'center', justifyContent: 'center' },
  fileName: { flex: 1.7, minWidth: 0, color: C.text, fontSize: 13, fontWeight: '500' },
  fileKind: { flex: 1.5, minWidth: 0, color: C.muted, fontSize: 13 },
  fileSize: { width: 85, color: C.muted, fontSize: 13 },
  radio: { width: 19, height: 19, borderRadius: 10, borderWidth: 2, borderColor: '#C2D0E4', alignItems: 'center', justifyContent: 'center' },
  radioActive: { borderColor: C.blue },
  radioDot: { width: 9, height: 9, borderRadius: 5, backgroundColor: C.blue },
  chosen: { flexDirection: 'row', alignItems: 'center', gap: 7, marginHorizontal: 24, marginTop: 12 },
  chosenText: { flex: 1, color: C.muted, fontSize: 12 },
  actions: { paddingHorizontal: 22, paddingTop: 23, alignItems: 'stretch' },
  scanButton: { minHeight: 47, borderRadius: 9, backgroundColor: C.blue, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10 },
  scanText: { color: C.white, fontSize: 14, fontWeight: '700' },
  browseButton: { marginTop: 8, minHeight: 36, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8 },
  browseText: { color: C.blue, fontSize: 13, fontWeight: '600' },
  cancelButton: { minHeight: 34, alignItems: 'center', justifyContent: 'center' },
  cancelText: { color: C.blue, fontSize: 13 },
  info: { flexDirection: 'row', alignItems: 'center', gap: 12, marginTop: 22, paddingVertical: 15, paddingHorizontal: 18, borderWidth: 1, borderColor: '#D9E9FF', borderRadius: 9, backgroundColor: '#EFF6FF' },
  infoText: { flex: 1, color: '#58749C', fontSize: 12, lineHeight: 19 },
});