import React, { useMemo, useState } from 'react';
import {
  Alert, Pressable, ScrollView, StatusBar, StyleSheet, Text, TextInput,
  View, useWindowDimensions,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Feather, MaterialCommunityIcons } from '@expo/vector-icons';

const C = {
  navy: '#192D47', text: '#172B49', blue: '#0878F9', paleBlue: '#EAF3FF',
  bg: '#F6FAFF', white: '#FFFFFF', muted: '#5D759B', border: '#DFEAF9',
  red: '#FA4246', orange: '#F59A23', green: '#1EB578',
};

type QuarantineFile = {
  id: string; name: string; description: string; type: string;
  date: string; time: string; status: 'Threat found' | 'Suspicious';
  reason: string; icon: 'file-pdf-box' | 'file-image'; iconColor: string;
};

const INITIAL_FILES: QuarantineFile[] = [
  {
    id: '1', name: 'Project_Proposal.pdf', description: 'PDF document',
    type: 'PDF', date: 'Oct 30, 2025', time: '10:24 AM',
    status: 'Threat found', reason: 'Malicious content detected.',
    icon: 'file-pdf-box', iconColor: C.red,
  },
  {
    id: '2', name: 'Screenshots_20251030.png', description: 'Image',
    type: 'Image', date: 'Oct 30, 2025', time: '09:17 AM',
    status: 'Suspicious', reason: 'Suspicious patterns detected.',
    icon: 'file-image', iconColor: C.blue,
  },
];

type Props = {
  onBackHome?: () => void;
  onScanFile?: () => void;
  onViewDetails?: (file: QuarantineFile) => void;
};

export default function QuarantineScreen({
  onBackHome, onScanFile, onViewDetails,
}: Props) {
  const { width } = useWindowDimensions();
  const desktop = width >= 950;
  const [files, setFiles] = useState(INITIAL_FILES);
  const [search, setSearch] = useState('');
  const [menuFor, setMenuFor] = useState<string | null>(null);

  const filteredFiles = useMemo(() => {
    const q = search.trim().toLowerCase();
    return q ? files.filter(f =>
      `${f.name} ${f.description} ${f.type} ${f.status} ${f.reason}`.toLowerCase().includes(q)
    ) : files;
  }, [files, search]);

  const details = (file: QuarantineFile) => {
    if (onViewDetails) onViewDetails(file);
    else Alert.alert(file.name, `${file.status}\n${file.reason}\n\nSample data only.`);
  };

  const removeFile = (file: QuarantineFile, action: 'delete' | 'restore') => {
    const title = action === 'delete' ? 'Delete quarantined file?' : 'Restore file?';
    const message = action === 'delete'
      ? `Remove "${file.name}" from this demo list?`
      : `Only restore "${file.name}" if you trust its source and understand the risk.`;
    Alert.alert(title, message, [
      { text: 'Cancel', style: 'cancel' },
      {
        text: action === 'delete' ? 'Delete' : 'Restore',
        style: action === 'delete' ? 'destructive' : 'default',
        onPress: () => {
          setFiles(current => current.filter(f => f.id !== file.id));
          setMenuFor(null);
          if (action === 'restore') {
            Alert.alert('Demo action', 'Removed from this sample list only. No real file was restored.');
          }
        },
      },
    ]);
  };

  return (
    <SafeAreaView style={s.safe}>
      <StatusBar barStyle="light-content" backgroundColor={C.navy} />
      <View style={s.app}>
        {desktop && <View style={s.sidebar}>
          <View style={s.brand}>
            <MaterialCommunityIcons name="shield-check" size={39} color={C.blue} />
            <Text style={s.brandText}>Security <Text style={s.brandAccent}>Scanner</Text></Text>
          </View>
          <View style={s.navList}>
            <Pressable style={s.navItem} onPress={onBackHome}><Feather name="home" size={21} color="#E1EAF6" /><Text style={s.navText}>Home</Text></Pressable>
            <Pressable style={s.navItem}><Feather name="clock" size={21} color="#E1EAF6" /><Text style={s.navText}>History</Text></Pressable>
            <Pressable style={[s.navItem, s.navActive]}><Feather name="archive" size={21} color={C.white} /><Text style={s.navText}>Quarantine</Text><View style={s.badge}><Text style={s.badgeText}>{files.length}</Text></View></Pressable>
            <Pressable style={s.navItem}><Feather name="settings" size={21} color="#E1EAF6" /><Text style={s.navText}>Settings</Text></Pressable>
          </View>
          <View style={s.privacy}>
            <MaterialCommunityIcons name="shield-check-outline" size={26} color="#75B8FF" />
            <View style={{ flex: 1 }}>
              <Text style={s.privacyTitle}>Files stay on your phone by default.</Text>
              <Text style={s.privacyCopy}>We don't upload your files without your permission.</Text>
            </View>
          </View>
        </View>}

        <View style={s.main}>
          <View style={s.topbar}>
            {!desktop && <Text style={s.mobileBrand}>Security <Text style={s.brandAccent}>Scanner</Text></Text>}
            <View style={s.userIcon}><Feather name="user" size={17} color={C.navy} /></View>
            <Text style={s.userText}>User</Text><Feather name="chevron-down" size={16} color="#8CA0BC" />
          </View>

          <ScrollView contentContainerStyle={[s.page, !desktop && s.pageMobile]}>
            <Pressable style={s.backLink} onPress={onBackHome}>
              <Feather name="arrow-left" size={18} color={C.blue} /><Text style={s.backText}>Back to Home</Text>
            </Pressable>

            <View style={s.heading}>
              <View style={s.headingIcon}><Feather name="archive" size={39} color={C.blue} /></View>
              <View style={s.headingCopy}>
                <Text style={s.pageTitle}>Quarantined files</Text>
                <Text style={s.subtitle}>These files are isolated because they may be harmful. Do not open them in the usual way.</Text>
              </View>
            </View>

            <View style={s.infoBanner}>
              <View style={s.infoCircle}><Feather name="info" size={20} color={C.white} /></View>
              <Text style={s.infoText}>Quarantined files are moved to a safe location on your device. They can't be opened or used by other apps until you take an action (e.g. delete or restore).</Text>
            </View>

            <View style={s.listCard}>
              <View style={[s.listHeader, !desktop && s.listHeaderMobile]}>
                <Text style={s.countText}>{files.length} {files.length === 1 ? 'file' : 'files'} quarantined</Text>
                <View style={s.searchBox}>
                  <Feather name="search" size={17} color={C.muted} />
                  <TextInput value={search} onChangeText={setSearch} placeholder="Search files..." placeholderTextColor="#8295B4" style={s.searchInput} accessibilityLabel="Search quarantined files" returnKeyType="search" />
                  {!!search && <Pressable onPress={() => setSearch('')}><Feather name="x-circle" size={17} color={C.muted} /></Pressable>}
                </View>
              </View>

              {desktop && <View style={s.tableHeader}>
                <Text style={[s.th, { flex: 2.15 }]}>File name</Text>
                <Text style={[s.th, { flex: 0.6 }]}>Type</Text>
                <Text style={[s.th, { flex: 1.1 }]}>Date quarantined ↓</Text>
                <Text style={[s.th, { flex: 2.1 }]}>Reason / status</Text>
                <Text style={[s.th, { width: 145, textAlign: 'center' }]}>Actions</Text>
              </View>}

              {filteredFiles.map(file => <View key={file.id} style={[s.fileRow, !desktop && s.fileRowMobile]}>
                <View style={s.fileIdentity}>
                  <View style={[s.fileIcon, { backgroundColor: file.iconColor }]}>
                    <MaterialCommunityIcons name={file.icon} size={28} color={C.white} />
                  </View>
                  <View style={s.fileNameBlock}>
                    <Text style={s.fileName}>{file.name}</Text>
                    <Text style={s.fileDescription}>{file.description}</Text>
                  </View>
                </View>
                {desktop && <Text style={[s.fileType, { flex: 0.6 }]}>{file.type}</Text>}
                <View style={s.dateBlock}><Text style={s.dateText}>{file.date}</Text><Text style={s.timeText}>{file.time}</Text></View>
                <View style={s.statusBlock}>
                  <View style={s.statusTitleRow}>
                    <Feather name={file.status === 'Threat found' ? 'alert-circle' : 'alert-triangle'} size={19} color={file.status === 'Threat found' ? C.red : C.orange} />
                    <Text style={[s.statusTitle, { color: file.status === 'Threat found' ? C.red : '#D77A08' }]}>{file.status}</Text>
                  </View>
                  <Text style={s.reasonText}>{file.reason}</Text>
                </View>
                <View style={[s.rowActions, !desktop && s.rowActionsMobile]}>
                  <Pressable style={s.detailsButton} onPress={() => details(file)}><Text style={s.detailsButtonText}>View details</Text></Pressable>
                  <Pressable style={s.moreButton} accessibilityLabel={`More actions for ${file.name}`} onPress={() => setMenuFor(menuFor === file.id ? null : file.id)}><Feather name="more-vertical" size={19} color={C.muted} /></Pressable>
                </View>
                {menuFor === file.id && <View style={s.actionMenu}>
                  <Pressable style={s.menuItem} onPress={() => removeFile(file, 'restore')}><Feather name="rotate-ccw" size={16} color={C.text} /><Text style={s.menuText}>Restore file</Text></Pressable>
                  <Pressable style={s.menuItem} onPress={() => removeFile(file, 'delete')}><Feather name="trash-2" size={16} color={C.red} /><Text style={[s.menuText, { color: C.red }]}>Delete permanently</Text></Pressable>
                </View>}
              </View>)}

              {filteredFiles.length === 0 && <View style={s.noResults}>
                <Feather name="search" size={28} color={C.muted} />
                <Text style={s.noResultsTitle}>No matching files</Text>
                <Text style={s.noResultsText}>Try another search term or clear the search.</Text>
                {!!search && <Pressable style={s.detailsButton} onPress={() => setSearch('')}><Text style={s.detailsButtonText}>Clear search</Text></Pressable>}
              </View>}

              <View style={s.emptyPanel}>
                <View style={s.emptyIcon}><Feather name="inbox" size={39} color={C.blue} /></View>
                <Text style={s.emptyTitle}>No quarantined files</Text>
                <Text style={s.emptyText}>Files you quarantine will appear here.</Text>
                <Pressable style={s.scanButton} onPress={onScanFile}><Feather name="file-plus" size={17} color={C.blue} /><Text style={s.scanButtonText}>Scan a file</Text></Pressable>
              </View>
            </View>
          </ScrollView>
        </View>
      </View>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  safe: { flex: 1, backgroundColor: C.bg },
  app: { flex: 1, flexDirection: 'row', backgroundColor: C.bg },
  sidebar: { width: 280, backgroundColor: C.navy, paddingHorizontal: 15, paddingTop: 15, paddingBottom: 22 },
  brand: { flexDirection: 'row', alignItems: 'center', gap: 9, paddingHorizontal: 8, paddingBottom: 22, borderBottomWidth: 1, borderBottomColor: '#263D58' },
  brandText: { color: C.white, fontSize: 21, fontWeight: '800' },
  brandAccent: { color: '#8EC5FF' },
  navList: { marginTop: 10, gap: 7 },
  navItem: { minHeight: 44, borderRadius: 9, paddingHorizontal: 12, flexDirection: 'row', alignItems: 'center', gap: 14 },
  navActive: { backgroundColor: '#214F84' },
  navText: { color: '#F0F5FC', fontSize: 15, flex: 1 },
  badge: { minWidth: 23, height: 23, borderRadius: 12, backgroundColor: '#FF5559', alignItems: 'center', justifyContent: 'center' },
  badgeText: { color: C.white, fontSize: 12, fontWeight: '700' },
  privacy: { marginTop: 'auto', borderTopWidth: 1, borderTopColor: '#314660', paddingTop: 18, flexDirection: 'row', gap: 12 },
  privacyTitle: { color: C.white, fontSize: 12, lineHeight: 18, fontWeight: '700' },
  privacyCopy: { color: '#CBD7E8', fontSize: 11, lineHeight: 17, marginTop: 5 },
  main: { flex: 1, minWidth: 0 },
  topbar: { height: 62, backgroundColor: C.white, borderBottomWidth: 1, borderBottomColor: '#E8EEF6', paddingHorizontal: 28, flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-end', gap: 10 },
  mobileBrand: { color: C.text, fontSize: 14, fontWeight: '800', marginRight: 'auto' },
  userIcon: { width: 22, height: 22, borderRadius: 11, backgroundColor: '#EDF3FC', alignItems: 'center', justifyContent: 'center' },
  userText: { color: C.text, fontSize: 14 },
  page: { paddingHorizontal: 36, paddingTop: 25, paddingBottom: 40, flexGrow: 1 },
  pageMobile: { paddingHorizontal: 15, paddingTop: 18 },
  backLink: { alignSelf: 'flex-start', flexDirection: 'row', alignItems: 'center', gap: 10 },
  backText: { color: C.blue, fontSize: 13, fontWeight: '500' },
  heading: { flexDirection: 'row', alignItems: 'center', gap: 23, marginTop: 25, marginBottom: 18 },
  headingIcon: { width: 82, height: 82, borderRadius: 16, backgroundColor: C.paleBlue, alignItems: 'center', justifyContent: 'center' },
  headingCopy: { flex: 1 },
  pageTitle: { color: C.text, fontSize: 31, lineHeight: 38, fontWeight: '800' },
  subtitle: { color: C.muted, fontSize: 16, lineHeight: 24, marginTop: 2 },
  infoBanner: { minHeight: 80, flexDirection: 'row', alignItems: 'center', gap: 21, paddingHorizontal: 23, paddingVertical: 15, backgroundColor: '#EEF6FF', borderWidth: 1, borderColor: '#D8E9FF', borderRadius: 8, marginBottom: 19 },
  infoCircle: { width: 29, height: 29, borderRadius: 15, backgroundColor: '#6399E5', alignItems: 'center', justifyContent: 'center' },
  infoText: { flex: 1, color: C.muted, fontSize: 13, lineHeight: 22 },
  listCard: { backgroundColor: C.white, borderWidth: 1, borderColor: C.border, borderRadius: 9, padding: 16 },
  listHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 16, marginBottom: 17 },
  listHeaderMobile: { flexDirection: 'column', alignItems: 'stretch' },
  countText: { color: C.text, fontSize: 17, fontWeight: '700' },
  searchBox: { width: 295, maxWidth: '100%', height: 38, flexDirection: 'row', alignItems: 'center', gap: 9, paddingHorizontal: 11, borderWidth: 1, borderColor: C.border, borderRadius: 7, backgroundColor: '#FBFDFF' },
  searchInput: { flex: 1, color: C.text, paddingVertical: 5, fontSize: 13 },
  tableHeader: { minHeight: 39, backgroundColor: '#F5F8FC', flexDirection: 'row', alignItems: 'center', paddingHorizontal: 13, gap: 13 },
  th: { color: C.muted, fontSize: 12, fontWeight: '600' },
  fileRow: { minHeight: 82, flexDirection: 'row', alignItems: 'center', gap: 13, paddingHorizontal: 13, paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: '#EAF0F8', position: 'relative' },
  fileRowMobile: { flexWrap: 'wrap', paddingHorizontal: 3, rowGap: 12 },
  fileIdentity: { flex: 2.15, minWidth: 190, flexDirection: 'row', alignItems: 'center', gap: 25 },
  fileIcon: { width: 36, height: 43, borderRadius: 7, alignItems: 'center', justifyContent: 'center' },
  fileNameBlock: { flex: 1, minWidth: 0 },
  fileName: { color: C.text, fontSize: 13, fontWeight: '600' },
  fileDescription: { color: C.muted, fontSize: 12, marginTop: 8 },
  fileType: { color: C.muted, fontSize: 12 },
  dateBlock: { flex: 1.1, minWidth: 115, gap: 6 },
  dateText: { color: C.muted, fontSize: 12 },
  timeText: { color: C.muted, fontSize: 12 },
  statusBlock: { flex: 2.1, minWidth: 180, gap: 5 },
  statusTitleRow: { flexDirection: 'row', alignItems: 'center', gap: 11 },
  statusTitle: { fontSize: 13, fontWeight: '500' },
  reasonText: { color: C.muted, fontSize: 12, lineHeight: 18, marginLeft: 31 },
  rowActions: { width: 145, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10 },
  rowActionsMobile: { width: '100%', justifyContent: 'flex-end' },
  detailsButton: { minHeight: 36, paddingHorizontal: 13, borderWidth: 1.5, borderColor: '#A8C8FF', borderRadius: 7, alignItems: 'center', justifyContent: 'center', backgroundColor: C.white },
  detailsButtonText: { color: C.blue, fontSize: 12, fontWeight: '600' },
  moreButton: { width: 36, height: 36, borderWidth: 1, borderColor: '#D4E2F5', borderRadius: 7, alignItems: 'center', justifyContent: 'center' },
  actionMenu: { position: 'absolute', right: 8, top: 52, zIndex: 10, minWidth: 190, paddingVertical: 5, borderWidth: 1, borderColor: C.border, borderRadius: 8, backgroundColor: C.white, shadowColor: '#122844', shadowOpacity: 0.12, shadowRadius: 12, shadowOffset: { width: 0, height: 5 }, elevation: 5 },
  menuItem: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingHorizontal: 12, paddingVertical: 11 },
  menuText: { color: C.text, fontSize: 12 },
  noResults: { alignItems: 'center', paddingVertical: 28, gap: 10 },
  noResultsTitle: { color: C.text, fontSize: 16, fontWeight: '700' },
  noResultsText: { color: C.muted, fontSize: 13, textAlign: 'center' },
  emptyPanel: { minHeight: 274, marginTop: 25, borderWidth: 1, borderColor: C.border, borderRadius: 9, backgroundColor: '#FBFDFF', alignItems: 'center', justifyContent: 'center', padding: 24 },
  emptyIcon: { width: 84, height: 84, borderRadius: 42, backgroundColor: C.paleBlue, alignItems: 'center', justifyContent: 'center', marginBottom: 14 },
  emptyTitle: { color: C.text, fontSize: 22, fontWeight: '800', textAlign: 'center' },
  emptyText: { color: C.muted, fontSize: 14, marginTop: 8, textAlign: 'center' },
  scanButton: { minHeight: 44, minWidth: 234, borderWidth: 1.5, borderColor: '#A8C8FF', borderRadius: 7, backgroundColor: C.white, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10, marginTop: 23, paddingHorizontal: 18 },
  scanButtonText: { color: C.blue, fontSize: 13, fontWeight: '600' },
});