import React, { useState } from "react";
import {
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Switch,
  Text,
  TouchableOpacity,
  View,
  useWindowDimensions,
} from "react-native";
import {
  ShieldCheck,
  House,
  History,
  Archive,
  Settings as SettingsIcon,
  LockKeyhole,
  Bell,
  CalendarDays,
  Trash2,
  Info,
  ChevronRight,
  ExternalLink,
} from "lucide-react-native";

type NavItemProps = {
  label: string;
  active?: boolean;
  badge?: string;
  icon: React.ReactNode;
  onPress?: () => void;
};

function NavItem({ label, active, badge, icon, onPress }: NavItemProps) {
  return (
    <TouchableOpacity
      accessibilityRole="button"
      onPress={onPress}
      style={[styles.navItem, active && styles.navItemActive]}
    >
      {icon}
      <Text style={styles.navLabel}>{label}</Text>
      {badge ? (
        <View style={styles.badge}>
          <Text style={styles.badgeText}>{badge}</Text>
        </View>
      ) : null}
    </TouchableOpacity>
  );
}

function SectionHeader({
  icon,
  title,
  subtitle,
}: {
  icon: React.ReactNode;
  title: string;
  subtitle: string;
}) {
  return (
    <View style={styles.sectionHeader}>
      <View style={styles.sectionIcon}>{icon}</View>
      <View style={styles.sectionHeaderText}>
        <Text style={styles.sectionTitle}>{title}</Text>
        <Text style={styles.sectionSubtitle}>{subtitle}</Text>
      </View>
      <ChevronRight size={21} color="#7896c8" />
    </View>
  );
}

function SettingsRow({
  label,
  value,
  chevron,
  onPress,
}: {
  label: string;
  value?: string;
  chevron?: boolean;
  onPress?: () => void;
}) {
  return (
    <TouchableOpacity
      accessibilityRole="button"
      onPress={onPress}
      style={styles.settingsRow}
    >
      <Text style={styles.settingsRowLabel}>{label}</Text>
      {value ? <Text style={styles.settingsRowValue}>{value}</Text> : null}
      {chevron ? <ChevronRight size={18} color="#7896c8" /> : null}
    </TouchableOpacity>
  );
}

export default function SettingsScreen() {
  const { width } = useWindowDimensions();
  const isWide = width >= 900;
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [retentionDays, setRetentionDays] = useState(30);

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar barStyle="dark-content" backgroundColor="#f7fbff" />
      <View style={styles.app}>
        {/* Desktop sidebar. On narrow screens it becomes a compact top navigation. */}
        {isWide ? (
          <View style={styles.sidebar}>
            <View style={styles.brand}>
              <View style={styles.brandMark}>
                <ShieldCheck size={28} color="#ffffff" strokeWidth={2.8} />
              </View>
              <Text style={styles.brandText}>
                Security <Text style={styles.brandAccent}>Scanner</Text>
              </Text>
            </View>

            <View style={styles.nav}>
              <NavItem
                label="Home"
                icon={<House size={21} color="#dceaff" fill="#dceaff" />}
              />
              <NavItem
                label="History"
                icon={<History size={22} color="#dceaff" />}
              />
              <NavItem
                label="Quarantine"
                badge="2"
                icon={<Archive size={21} color="#dceaff" />}
              />
              <NavItem
                label="Settings"
                active
                icon={<SettingsIcon size={21} color="#ffffff" strokeWidth={2.8} />}
              />
            </View>

            <View style={styles.sidebarNote}>
              <ShieldCheck size={25} color="#65b9ff" />
              <View style={styles.sidebarNoteText}>
                <Text style={styles.sidebarNoteTitle}>
                  Files stay on your phone{"\n"}by default.
                </Text>
                <Text style={styles.sidebarNoteBody}>
                  We don't upload your files or personal data without your
                  permission.
                </Text>
              </View>
            </View>
          </View>
        ) : (
          <View style={styles.mobileTopbar}>
            <View style={styles.brandMark}>
              <ShieldCheck size={24} color="#ffffff" strokeWidth={2.8} />
            </View>
            <Text style={styles.mobileBrand}>
              Security <Text style={styles.brandAccent}>Scanner</Text>
            </Text>
            <Text style={styles.mobileUser}>● User</Text>
          </View>
        )}

        <View style={styles.main}>
          {isWide ? (
            <View style={styles.topbar}>
              <View />
              <Text style={styles.userMenu}>●  User   ⌄</Text>
            </View>
          ) : null}

          <ScrollView
            style={styles.scroll}
            contentContainerStyle={[
              styles.content,
              !isWide && styles.contentMobile,
            ]}
            showsVerticalScrollIndicator={false}
          >
            <View style={styles.pageHeader}>
              <View style={styles.pageIcon}>
                <SettingsIcon size={35} color="#0877ff" strokeWidth={2.8} />
              </View>
              <View style={styles.pageHeaderText}>
                <Text style={styles.pageTitle}>Settings</Text>
                <Text style={styles.pageSubtitle}>
                  Manage your privacy, notifications and app preferences.
                </Text>
              </View>
            </View>

            {/* Privacy */}
            <View style={styles.card}>
              <SectionHeader
                icon={<LockKeyhole size={27} color="#0877ff" strokeWidth={2.5} />}
                title="Privacy"
                subtitle="Control how your data is handled and learn what we collect."
              />
              <View style={styles.sectionBodyIndented}>
                <View style={styles.infoBanner}>
                  <Info size={20} color="#ffffff" fill="#4b94f5" />
                  <Text style={styles.infoBannerText}>
                    Files remain on your phone by default. We don’t upload your
                    files or personal data without your permission.
                  </Text>
                </View>
                <TouchableOpacity style={styles.learnMore}>
                  <Text style={styles.learnMoreText}>Learn more about our privacy</Text>
                  <ExternalLink size={15} color="#0877ff" />
                </TouchableOpacity>
              </View>
            </View>

            {/* Notifications */}
            <View style={styles.card}>
              <SectionHeader
                icon={<Bell size={27} color="#0877ff" strokeWidth={2.5} />}
                title="Notifications"
                subtitle="Get alerts for important events, such as threats and scan results."
              />
              <View style={styles.notificationRow}>
                <Text style={styles.notificationLabel}>Enable notifications</Text>
                <Switch
                  value={notificationsEnabled}
                  onValueChange={setNotificationsEnabled}
                  trackColor={{ false: "#c8d5e8", true: "#0877ff" }}
                  thumbColor="#ffffff"
                  accessibilityLabel="Enable notifications"
                />
              </View>
            </View>

            {/* Quarantine retention */}
            <View style={styles.card}>
              <SectionHeader
                icon={<ShieldCheck size={28} color="#0877ff" strokeWidth={2.5} />}
                title="Quarantine retention"
                subtitle="Files in quarantine are automatically deleted after a set period."
              />
              <View style={styles.retentionBody}>
                <View style={styles.retentionSummary}>
                  <CalendarDays size={25} color="#5575a8" />
                  <View style={styles.retentionText}>
                    <Text style={styles.smallLabel}>Current retention period</Text>
                    <Text style={styles.retentionValue}>{retentionDays} days</Text>
                    <Text style={styles.mutedText}>
                      Files will be deleted automatically after {retentionDays} days
                      in quarantine.
                    </Text>
                  </View>
                </View>

                <View style={styles.manageRetention}>
                  <Text style={styles.manageTitle}>Manage</Text>
                  <TouchableOpacity
                    style={styles.manageAction}
                    onPress={() => setRetentionDays((days) => (days === 30 ? 14 : 30))}
                  >
                    <View style={styles.manageIcon}>
                      <Trash2 size={20} color="#365b8e" />
                    </View>
                    <View style={styles.manageText}>
                      <Text style={styles.manageActionTitle}>
                        Delete quarantined files
                      </Text>
                      <Text style={styles.mutedText}>
                        Remove files from quarantine now.
                      </Text>
                    </View>
                    <ChevronRight size={18} color="#7896c8" />
                  </TouchableOpacity>
                </View>
              </View>
            </View>

            {/* App information */}
            <View style={styles.card}>
              <SectionHeader
                icon={<Info size={27} color="#0877ff" strokeWidth={2.5} />}
                title="App information"
                subtitle="View version and useful links."
              />
              <View style={styles.appInfoRows}>
                <SettingsRow label="App version" value="1.0.0" />
                <SettingsRow label="Build number" value="100" />
                <SettingsRow label="Terms of service" chevron />
                <SettingsRow label="Privacy policy" chevron />
              </View>
            </View>
          </ScrollView>
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: "#f5f9fe",
  },
  app: {
    flex: 1,
    flexDirection: "row",
    backgroundColor: "#f5f9fe",
  },
  sidebar: {
    width: 280,
    backgroundColor: "#14263b",
    paddingTop: 17,
    paddingHorizontal: 15,
    borderRightWidth: 1,
    borderRightColor: "#dce8f7",
  },
  brand: {
    height: 66,
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 9,
    borderBottomWidth: 1,
    borderBottomColor: "#263b54",
    marginHorizontal: -15,
    paddingLeft: 25,
    paddingBottom: 15,
  },
  brandMark: {
    width: 38,
    height: 42,
    borderRadius: 13,
    backgroundColor: "#0877ff",
    alignItems: "center",
    justifyContent: "center",
    marginRight: 10,
  },
  brandText: {
    color: "#ffffff",
    fontSize: 20,
    fontWeight: "800",
    letterSpacing: -0.5,
  },
  brandAccent: {
    color: "#68c1ff",
  },
  nav: {
    paddingTop: 9,
    gap: 6,
  },
  navItem: {
    height: 46,
    borderRadius: 8,
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 13,
    gap: 14,
  },
  navItemActive: {
    backgroundColor: "#174b87",
  },
  navLabel: {
    color: "#f3f7ff",
    fontSize: 15,
    fontWeight: "600",
    flex: 1,
  },
  badge: {
    minWidth: 23,
    height: 23,
    borderRadius: 12,
    backgroundColor: "#ff4d55",
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 5,
  },
  badgeText: {
    color: "#ffffff",
    fontSize: 12,
    fontWeight: "700",
  },
  sidebarNote: {
    marginTop: "auto",
    marginBottom: 24,
    paddingTop: 20,
    borderTopWidth: 1,
    borderTopColor: "#2b4058",
    flexDirection: "row",
    gap: 12,
  },
  sidebarNoteText: {
    flex: 1,
  },
  sidebarNoteTitle: {
    color: "#f3f7ff",
    fontSize: 12,
    fontWeight: "700",
    lineHeight: 19,
  },
  sidebarNoteBody: {
    color: "#c5d3e7",
    fontSize: 12,
    lineHeight: 19,
    marginTop: 5,
  },
  main: {
    flex: 1,
    minWidth: 0,
  },
  topbar: {
    height: 62,
    backgroundColor: "#ffffff",
    borderBottomWidth: 1,
    borderBottomColor: "#e3edf9",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 29,
  },
  userMenu: {
    color: "#172d4b",
    fontSize: 14,
    fontWeight: "600",
  },
  scroll: {
    flex: 1,
  },
  content: {
    paddingHorizontal: 38,
    paddingTop: 20,
    paddingBottom: 34,
    gap: 14,
  },
  contentMobile: {
    paddingHorizontal: 16,
    paddingTop: 20,
  },
  mobileTopbar: {
    minHeight: 62,
    backgroundColor: "#14263b",
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 15,
  },
  mobileBrand: {
    color: "#ffffff",
    fontSize: 18,
    fontWeight: "800",
    flex: 1,
  },
  mobileUser: {
    color: "#ffffff",
    fontSize: 13,
  },
  pageHeader: {
    flexDirection: "row",
    alignItems: "center",
    gap: 23,
    marginBottom: 5,
  },
  pageIcon: {
    width: 71,
    height: 71,
    borderRadius: 15,
    backgroundColor: "#e3f0ff",
    alignItems: "center",
    justifyContent: "center",
  },
  pageHeaderText: {
    flex: 1,
  },
  pageTitle: {
    color: "#142a47",
    fontSize: 30,
    fontWeight: "800",
    letterSpacing: -0.8,
  },
  pageSubtitle: {
    color: "#5b77a7",
    fontSize: 16,
    lineHeight: 23,
    marginTop: 2,
  },
  card: {
    backgroundColor: "rgba(255,255,255,0.91)",
    borderColor: "#e0ebfb",
    borderWidth: 1,
    borderRadius: 9,
    paddingHorizontal: 19,
    paddingVertical: 17,
    shadowColor: "#91afd4",
    shadowOpacity: 0.06,
    shadowRadius: 9,
    shadowOffset: { width: 0, height: 2 },
    elevation: 1,
  },
  sectionHeader: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 24,
  },
  sectionIcon: {
    width: 50,
    height: 50,
    borderRadius: 10,
    backgroundColor: "#e4f1ff",
    alignItems: "center",
    justifyContent: "center",
  },
  sectionHeaderText: {
    flex: 1,
    paddingTop: 5,
  },
  sectionTitle: {
    color: "#142a47",
    fontSize: 16,
    fontWeight: "800",
  },
  sectionSubtitle: {
    color: "#5b77a7",
    fontSize: 13,
    lineHeight: 20,
    marginTop: 5,
  },
  sectionBodyIndented: {
    marginLeft: 74,
    marginTop: 15,
    flexDirection: "row",
    alignItems: "center",
    gap: 28,
  },
  infoBanner: {
    backgroundColor: "#eff7ff",
    borderColor: "#dcecff",
    borderWidth: 1,
    borderRadius: 7,
    paddingHorizontal: 13,
    paddingVertical: 12,
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 15,
    flex: 1,
  },
  infoBannerText: {
    color: "#3869b2",
    fontSize: 12,
    lineHeight: 21,
    flex: 1,
  },
  learnMore: {
    flexDirection: "row",
    alignItems: "center",
    gap: 7,
    paddingHorizontal: 3,
  },
  learnMoreText: {
    color: "#0877ff",
    fontSize: 11,
    fontWeight: "600",
  },
  notificationRow: {
    marginLeft: 74,
    marginTop: 12,
    minHeight: 32,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "flex-end",
    gap: 115,
  },
  notificationLabel: {
    color: "#142a47",
    fontSize: 13,
    fontWeight: "600",
  },
  retentionBody: {
    marginLeft: 76,
    marginTop: 17,
    flexDirection: "row",
    alignItems: "stretch",
    gap: 34,
  },
  retentionSummary: {
    flex: 1,
    minHeight: 100,
    backgroundColor: "#f2f8ff",
    borderColor: "#e0efff",
    borderWidth: 1,
    borderRadius: 7,
    paddingHorizontal: 20,
    paddingVertical: 15,
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 21,
  },
  retentionText: {
    flex: 1,
  },
  smallLabel: {
    color: "#526f9f",
    fontSize: 12,
  },
  retentionValue: {
    color: "#142a47",
    fontSize: 18,
    fontWeight: "800",
    marginTop: 7,
  },
  mutedText: {
    color: "#6480ae",
    fontSize: 12,
    lineHeight: 19,
    marginTop: 5,
  },
  manageRetention: {
    flex: 1,
    borderLeftWidth: 1,
    borderLeftColor: "#e5eef9",
    paddingLeft: 34,
    justifyContent: "center",
  },
  manageTitle: {
    color: "#142a47",
    fontSize: 12,
    fontWeight: "800",
    marginBottom: 11,
  },
  manageAction: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
  },
  manageIcon: {
    width: 33,
    height: 33,
    borderRadius: 17,
    backgroundColor: "#edf5ff",
    alignItems: "center",
    justifyContent: "center",
  },
  manageText: {
    flex: 1,
  },
  manageActionTitle: {
    color: "#243f67",
    fontSize: 12,
    fontWeight: "600",
  },
  appInfoRows: {
    marginLeft: 76,
    marginTop: 11,
  },
  settingsRow: {
    minHeight: 37,
    borderBottomWidth: 1,
    borderBottomColor: "#e7eff9",
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
  settingsRowLabel: {
    color: "#5876a6",
    fontSize: 13,
    flex: 1,
  },
  settingsRowValue: {
    color: "#5876a6",
    fontSize: 13,
  },
});